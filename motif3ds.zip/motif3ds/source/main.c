/* Motif for 3DS - offline v0.1
 * Top screen: the garden (walk with Circle Pad / D-Pad).
 * Bottom screen: 16-step motif editor (tap to place / remove notes).
 * A = play your motif in the world, Y = chat, X = change name,
 * SELECT = sound on/off, START = quit.
 */
#include <3ds.h>
#include <citro2d.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#define Z 0.5f
#define RGB(h)     C2D_Color32(((h) >> 16) & 255, ((h) >> 8) & 255, (h) & 255, 255)
#define RGBA(h, a) C2D_Color32(((h) >> 16) & 255, ((h) >> 8) & 255, (h) & 255, (a))
#define CLAMP(v, a, b) ((v) < (a) ? (a) : (v) > (b) ? (b) : (v))

enum { ZW = 1400, ZH = 1200, WW = ZW * 3, WH = ZH * 2, WP = 64 };
#define VIEW 0.5f      /* world px -> screen px */
#define HEAR 950.0f
#define STEP_MS 365
#define SAVE "sdmc:/3ds/motif/save.bin"

/* ---------------------------------------------------------------- world */
static const char *ZNAME[6] = {"Whisper Woods", "Sunny Meadow", "Frost Hill",
                               "Sandy Shore", "Motif Garden", "Lantern Village"};
static const u32 ZCOL[6] = {0x7ea06f, 0xa6c57f, 0xdfe8ef, 0xe6d5a5, 0x94b383, 0xb9b29a};
static const int SEG[7][2] = {{0,1},{1,2},{3,4},{4,5},{0,3},{1,4},{2,5}};

static int zoneAt(float x, float y) {
    int c = (int)(x / ZW), r = (int)(y / ZH);
    c = CLAMP(c, 0, 2); r = CLAMP(r, 0, 1);
    return c + 3 * r;
}
static void zc(int i, float *x, float *y) {
    *x = (i % 3) * ZW + ZW / 2.0f;
    *y = (i / 3) * ZH + ZH / 2.0f;
}
static float pathDist(float x, float y) {
    float m = 1e9f;
    for (int i = 0; i < 7; i++) {
        float ax, ay, bx, by;
        zc(SEG[i][0], &ax, &ay); zc(SEG[i][1], &bx, &by);
        float dx = bx - ax, dy = by - ay;
        float t = CLAMP(((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy), 0.0f, 1.0f);
        float d = hypotf(x - ax - t * dx, y - ay - t * dy);
        if (d < m) m = d;
    }
    return m;
}

typedef struct { float x, y; int kind, v; } Tree;
static Tree trees[256];
static int ntrees;
static float fx[300], fy[300];
static int nflowers;
static unsigned seed = 7;

static float rnd(void) {
    seed = (unsigned)(((unsigned long long)seed * 16807ULL) % 2147483647ULL);
    return seed / 2147483647.0f;
}
static float hashf(float n) {
    float x = sinf(n * 127.1f + 34.7f) * 43758.5453f;
    return x - floorf(x);
}
static bool treeBlocked(float x, float y) {
    for (int i = 0; i < ntrees; i++) {
        float dx = (x - trees[i].x) / 16.0f, dy = (y - trees[i].y) / 10.0f;
        if (dx * dx + dy * dy < 1.0f) return true;
    }
    return false;
}
static void placeTrees(int zi, int count, int kind, int variants) {
    float x0 = (zi % 3) * ZW, y0 = (zi / 3) * ZH;
    int n = 0, tries = 0;
    while (n < count && tries++ < count * 40 && ntrees < 256) {
        float x = x0 + 80 + rnd() * (ZW - 160), y = y0 + 170 + rnd() * (ZH - 260);
        if (pathDist(x, y) < WP / 2 + 70) continue;
        if (zi == 4 && hypotf(x - 2100, y - 1830) < 280) continue;
        bool close = false;
        for (int j = 0; j < ntrees; j++)
            if (fabsf(trees[j].x - x) < 64 && fabsf(trees[j].y - y) < 36) { close = true; break; }
        if (close) continue;
        trees[ntrees++] = (Tree){x, y, kind, (int)(rnd() * variants)};
        n++;
    }
}
static void buildWorld(void) {
    placeTrees(0, 50, 0, 3); placeTrees(1, 12, 1, 2); placeTrees(2, 30, 2, 1);
    placeTrees(3, 12, 3, 1); placeTrees(4, 10, 0, 3); placeTrees(5, 10, 4, 2);
    int zs[2] = {1, 4};
    for (int k = 0; k < 2; k++) {
        float x0 = (zs[k] % 3) * ZW, y0 = (zs[k] / 3) * ZH;
        for (int i = 0; i < 150 && nflowers < 300; i++) {
            float x = x0 + 60 + hashf(zs[k] * 97 + i * 3.1f) * (ZW - 120);
            float y = y0 + 60 + hashf(zs[k] * 31 + i * 7.7f + .5f) * (ZH - 120);
            if (pathDist(x, y) > WP / 2 + 8) { fx[nflowers] = x; fy[nflowers] = y; nflowers++; }
        }
    }
}

/* ----------------------------------------------------------- characters */
typedef struct {
    float x, y, phase, tx, ty, wait, sing;
    int face; bool moving;
    u32 skin, hair, coat, sleeve, pants, shoe, accent;
    char name[24], say[64];
    u64 sayUntil;
} Char;
static Char player, vis[2];

static void initChar(Char *c, float x, float y, u32 skin, u32 hair, u32 coat, u32 sleeve,
                     u32 pants, u32 shoe, u32 accent, const char *name, float wait, float sing) {
    memset(c, 0, sizeof *c);
    c->x = x; c->y = y; c->face = 1; c->tx = x; c->ty = y; c->wait = wait; c->sing = sing;
    c->skin = skin; c->hair = hair; c->coat = coat; c->sleeve = sleeve;
    c->pants = pants; c->shoe = shoe; c->accent = accent;
    snprintf(c->name, sizeof c->name, "%s", name);
}
static bool stepTo(Char *c, float dx, float dy, float d, float dt, float speed) {
    float nx = CLAMP(c->x + dx / d * speed * dt, 40.0f, WW - 40.0f);
    float ny = CLAMP(c->y + dy / d * speed * dt, 150.0f, WH - 24.0f);
    bool moved = false;
    if (!treeBlocked(nx, ny)) { c->x = nx; c->y = ny; moved = true; }
    else if (!treeBlocked(nx, c->y)) { c->x = nx; moved = true; }
    else if (!treeBlocked(c->x, ny)) { c->y = ny; moved = true; }
    if (moved) { if (fabsf(dx) > .5f) c->face = dx > 0 ? 1 : -1; c->phase += dt * 8; }
    c->moving = moved;
    return moved;
}
static void pickTarget(Char *v) {
    for (int i = 0; i < 14; i++) {
        float x = 1500 + rnd() * 1200, y = 1400 + rnd() * 850;
        if (!treeBlocked(x, y)) { v->tx = x; v->ty = y; return; }
    }
}

/* ---------------------------------------------------------------- audio */
#define SR 32000
#define NOTE_N (SR * 42 / 100)
static const char *PITCH[15] = {"C4","D4","E4","F4","G4","A4","B4","C5","D5","E5","F5","G5","A5","B5","C6"};
static const int SEMI[15] = {0,2,4,5,7,9,11,12,14,16,17,19,21,23,24};
static s16 *notebuf[15];
static ndspWaveBuf wbuf[8];
static bool audioOk, muted;
static int nextCh;

static void audioInit(void) {
    if (R_FAILED(ndspInit())) return;   /* needs dspfirm.cdn (DSP1) on the SD card */
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    for (int ch = 0; ch < 8; ch++) {
        ndspChnReset(ch);
        ndspChnSetInterp(ch, NDSP_INTERP_LINEAR);
        ndspChnSetRate(ch, SR);
        ndspChnSetFormat(ch, NDSP_FORMAT_MONO_PCM16);
    }
    for (int p = 0; p < 15; p++) {
        notebuf[p] = linearAlloc(NOTE_N * sizeof(s16));
        if (!notebuf[p]) return;
        float f = 261.6256f * powf(2.0f, SEMI[p] / 12.0f);
        for (int i = 0; i < NOTE_N; i++) {
            float t = (float)i / SR;
            float env = t < 0.025f ? t / 0.025f : expf(-(t - 0.025f) * 9.0f);
            float tail = fminf(1.0f, (float)(NOTE_N - i) / 200.0f);
            float s = env * tail * (sinf(6.2831853f * f * t) + 0.22f * sinf(12.5663706f * f * t)) * 0.3f;
            notebuf[p][i] = (s16)(s * 32767.0f);
        }
        DSP_FlushDataCache(notebuf[p], NOTE_N * sizeof(s16));
    }
    audioOk = true;
}
static void playNote(int p, float vol, float pan) {
    if (!audioOk || muted || p < 0 || p > 14) return;
    int ch = nextCh++ & 7;
    float mix[12] = {0};
    mix[0] = vol * (pan <= 0 ? 1.0f : 1.0f - pan);
    mix[1] = vol * (pan >= 0 ? 1.0f : 1.0f + pan);
    ndspChnWaveBufClear(ch);
    ndspChnSetMix(ch, mix);
    memset(&wbuf[ch], 0, sizeof wbuf[ch]);
    wbuf[ch].data_vaddr = notebuf[p];
    wbuf[ch].nsamples = NOTE_N;
    wbuf[ch].looping = false;
    ndspChnWaveBufAdd(ch, &wbuf[ch]);
}

/* --------------------------------------------------- motif + singing */
static int8_t saved[16] = {4,5,6,7,8,7,6,4, 2,4,5,7,6,5,4,7};
typedef struct { bool on; int8_t mel[16]; int len, step; u64 next; Char *who; } Singer;
static Singer sing[3];
typedef struct { float x, y, life; } Burst;
static Burst bursts[32];

static void addBurst(float x, float y) {
    for (int i = 0; i < 32; i++)
        if (bursts[i].life <= 0) {
            bursts[i] = (Burst){x + (rand() % 34 - 17), y - 60, 1.1f};
            return;
        }
}
static void singerStart(int i, const int8_t *m, int len) {
    Singer *s = &sing[i];
    memcpy(s->mel, m, len);
    s->len = len; s->step = 0; s->next = osGetTime(); s->on = true;
}
static void singersUpdate(u64 now) {
    for (int i = 0; i < 3; i++) {
        Singer *s = &sing[i];
        while (s->on && now >= s->next) {
            int n = s->mel[s->step];
            if (n >= 0) {
                float d = hypotf(s->who->x - player.x, (s->who->y - player.y) * 1.3f);
                float v = powf(CLAMP(1.0f - d / HEAR, 0.0f, 1.0f), 1.6f) * 0.7f;
                if (i == 0) v = 0.7f;
                float pan = CLAMP((s->who->x - player.x) / 450.0f, -1.0f, 1.0f);
                if (v > 0.03f) playNote(n, v, pan);
                addBurst(s->who->x, s->who->y);
            }
            s->step++; s->next += STEP_MS;
            if (s->step >= s->len) s->on = false;
        }
    }
}

/* ------------------------------------------------------------ save/load */
static char username[17] = "Player";
static bool validName(const char *n) {
    size_t l = strlen(n);
    if (l < 2 || l > 16) return false;
    for (size_t i = 0; i < l; i++) {
        char c = n[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
              c == ' ' || c == '_' || c == '-')) return false;
    }
    return true;
}
static void loadSave(void) {
    FILE *f = fopen(SAVE, "rb");
    if (!f) return;
    int8_t b[16]; char n[17] = {0};
    if (fread(b, 1, 16, f) == 16) {
        bool ok = true;
        for (int i = 0; i < 16; i++) if (b[i] < -1 || b[i] > 14) ok = false;
        if (ok) memcpy(saved, b, 16);
        if (fread(n, 1, 16, f) == 16 && validName(n)) snprintf(username, sizeof username, "%s", n);
    }
    fclose(f);
}
static void saveNow(void) {
    mkdir("sdmc:/3ds", 0777); mkdir("sdmc:/3ds/motif", 0777);
    FILE *f = fopen(SAVE, "wb");
    if (!f) return;
    char n[17] = {0};
    snprintf(n, sizeof n, "%s", username);
    fwrite(saved, 1, 16, f); fwrite(n, 1, 16, f);
    fclose(f);
}

/* ----------------------------------------------------------------- chat */
typedef struct { char name[24]; char text[121]; u64 at; } Line;
static Line chat[6];
static int nchat;
static void addChat(const char *n, const char *t) {
    if (nchat == 6) { memmove(chat, chat + 1, sizeof(Line) * 5); nchat = 5; }
    snprintf(chat[nchat].name, sizeof chat[nchat].name, "%s", n);
    snprintf(chat[nchat].text, sizeof chat[nchat].text, "%s", t);
    chat[nchat].at = osGetTime();
    nchat++;
}
static bool askText(const char *hint, char *out, size_t cap, int minLen, int maxLen) {
    SwkbdState kb;
    swkbdInit(&kb, SWKBD_TYPE_NORMAL, 2, maxLen);
    swkbdSetHintText(&kb, hint);
    swkbdSetValidation(&kb, SWKBD_NOTEMPTY_NOTBLANK, 0, 0);
    (void)minLen;
    return swkbdInputText(&kb, out, cap) == SWKBD_BUTTON_CONFIRM;
}

/* -------------------------------------------------------------- drawing */
static C2D_TextBuf tbuf;
static float camx, camy;
#define SX(wx) (((wx) - camx) * VIEW)
#define SY(wy) (((wy) - camy) * VIEW)

static void rect(float x, float y, float w, float h, u32 c) { C2D_DrawRectSolid(x, y, Z, w, h, c); }
static void txt(const char *s, float x, float y, float sz, u32 col, int center) {
    C2D_Text t;
    C2D_TextParse(&t, tbuf, s); C2D_TextOptimize(&t);
    float w, h; C2D_TextGetDimensions(&t, sz, sz, &w, &h);
    if (center) x -= w / 2;
    C2D_DrawText(&t, C2D_WithColor, x, y, Z, sz, sz, col);
}
static float txtW(const char *s, float sz) {
    C2D_Text t; C2D_TextParse(&t, tbuf, s);
    float w, h; C2D_TextGetDimensions(&t, sz, sz, &w, &h);
    return w;
}
static void nameTag(float sx, float sy, const char *label) {
    float w = txtW(label, 0.4f) + 8;
    rect(sx - w / 2, sy - 12, w, 14, RGB(0xfff9e9));
    txt(label, sx, sy - 12, 0.4f, RGB(0x34453e), 1);
}
static void drawChar(Char *c, float sx, float sy) {
    const float u = 2.0f;
    int step = ((int)(c->phase / 1.5f)) & 1;
    float bob = c->moving ? (step ? -u : 0) : 0;
    float x0 = sx - 7 * u, y0 = sy - 21 * u + bob;
    float eye = c->face > 0 ? 1.0f : -1.0f;
    rect(sx - 6 * u, sy - u, 12 * u, 1.5f * u, RGBA(0x2f453a, 58));
    float la = c->moving && step ? -u : 0, lb = c->moving && !step ? -u : 0;
    rect(x0 + 4 * u, y0 + 15 * u + la, 3 * u, 4 * u, c->pants);
    rect(x0 + 8 * u, y0 + 15 * u + lb, 3 * u, 4 * u, c->pants);
    rect(x0 + 3 * u, y0 + 19 * u + la, 4 * u, 2 * u, c->shoe);
    rect(x0 + 8 * u, y0 + 19 * u + lb, 4 * u, 2 * u, c->shoe);
    rect(x0 + 2 * u, y0 + 10 * u, 11 * u, 5 * u, c->coat);
    rect(x0 + 1 * u, y0 + 10 * u, 1 * u, 4 * u, c->sleeve);
    rect(x0 + 13 * u, y0 + 10 * u, 1 * u, 4 * u, c->sleeve);
    rect(x0 + 4 * u, y0 + 10 * u, 7 * u, 1 * u, c->accent);
    rect(x0 + 2 * u, y0 + 1 * u, 11 * u, 9 * u, c->hair);
    rect(x0 + 3 * u, y0 + 4 * u, 9 * u, 6 * u, c->skin);
    rect(x0 + (5 + eye * 0.5f) * u, y0 + 6 * u, 1 * u, 1 * u, RGB(0x2b2530));
    rect(x0 + (9 + eye * 0.5f) * u, y0 + 6 * u, 1 * u, 1 * u, RGB(0x2b2530));
    rect(x0 + (7 + eye * 0.5f) * u, y0 + 8 * u, 1 * u, 1 * u, RGB(0x9a5a52));
    nameTag(sx, y0 - 4, c->name);
    if (c->say[0] && c->sayUntil > osGetTime()) {
        char b[40]; snprintf(b, sizeof b, "%.30s", c->say);
        float w = txtW(b, 0.4f) + 10;
        rect(sx - w / 2, y0 - 36, w, 18, RGB(0x34453e));
        rect(sx - w / 2 + 1, y0 - 35, w - 2, 16, RGB(0xfffdf3));
        txt(b, sx, y0 - 35, 0.4f, RGB(0x34453e), 1);
    }
}
static void drawTree(const Tree *t, float sx, float sy) {
    static const u32 G[3][3] = {{0x4f7a52,0x6a9a5f,0x8cb872},{0x46704d,0x5f8f57,0x82ad6a},{0x587f4a,0x78a35c,0x9cc47a}};
    rect(sx - 8, sy - 3, 16, 5, RGBA(0x2f4a35, 58));
    if (t->kind == 0 || t->kind == 1 || t->kind == 4) {
        float s = t->kind == 4 ? 0.7f : 1.0f;
        rect(sx - 3 * s, sy - 22 * s, 6 * s, 22 * s, RGB(0x6b5240));
        const u32 *c = G[t->v % 3];
        u32 c0 = c[0], c1 = c[1], c2 = c[2];
        if (t->kind == 1) { c0 = 0x6f9f58; c1 = 0x8cbc6c; c2 = 0xa9d67f; }
        C2D_DrawCircleSolid(sx, sy - 26 * s, Z, 22 * s, RGB(c0));
        C2D_DrawCircleSolid(sx - 6 * s, sy - 32 * s, Z, 16 * s, RGB(c1));
        C2D_DrawCircleSolid(sx - 10 * s, sy - 38 * s, Z, 6 * s, RGB(c2));
        if (t->kind == 1)
            for (int i = 0; i < 8; i++)
                rect(sx - 16 + hashf(i * 3.3f + t->x) * 32, sy - 44 + hashf(i * 5.1f + t->y) * 26, 2, 2, RGB(0xf4b8c8));
    } else if (t->kind == 2) {
        rect(sx - 3, sy - 10, 6, 10, RGB(0x6b5240));
        for (int i = 0; i < 3; i++) {
            float w = 38 - i * 10, y = sy - 20 - i * 14;
            rect(sx - w / 2, y, w, 14, RGB(i % 2 ? 0x3f6b55 : 0x4a7a60));
            rect(sx - w / 2, y, w, 3, RGB(0xf4f8fb));
        }
    } else {
        rect(sx - 2, sy - 40, 4, 40, RGB(0x8a6a48));
        static const float fa[5][2] = {{-22,6},{-12,-4},{0,-8},{12,-4},{22,6}};
        for (int i = 0; i < 5; i++)
            C2D_DrawLine(sx, sy - 40, RGB(0x4f9a5a), sx + fa[i][0], sy - 40 + fa[i][1], RGB(0x5aa862), 4, Z);
    }
}
typedef struct { float y; int type, idx; } Item;
static int cmpItem(const void *a, const void *b) {
    float d = ((const Item *)a)->y - ((const Item *)b)->y;
    return d < 0 ? -1 : d > 0 ? 1 : 0;
}

static void drawWorld(float t, int zoneBanner, float bannerAlpha) {
    for (int z = 0; z < 6; z++)
        rect(SX((z % 3) * ZW), SY((z / 3) * ZH), ZW * VIEW + 1, ZH * VIEW + 1, RGB(ZCOL[z]));
    for (int pass = 0; pass < 2; pass++) {
        float pad = pass == 0 ? 8.0f : 0.0f;
        u32 col = RGB(pass == 0 ? 0xc4a874 : 0xe4cd9d);
        for (int i = 0; i < 7; i++) {
            float ax, ay, bx, by;
            zc(SEG[i][0], &ax, &ay); zc(SEG[i][1], &bx, &by);
            if (ay == by) rect(SX(ax - pad / 2), SY(ay - WP / 2 - pad / 2), (bx - ax + pad) * VIEW, (WP + pad) * VIEW, col);
            else          rect(SX(ax - WP / 2 - pad / 2), SY(ay - pad / 2), (WP + pad) * VIEW, (by - ay + pad) * VIEW, col);
        }
    }
    static const u32 FC[4] = {0xf4c9a0, 0xfbeed2, 0xe8a9b0, 0xe6b84f};
    for (int i = 0; i < nflowers; i++) {
        float sx = SX(fx[i]), sy = SY(fy[i]);
        if (sx < -4 || sx > 404 || sy < -4 || sy > 244) continue;
        rect(sx - 2, sy, 5, 2, RGB(FC[i % 4])); rect(sx, sy - 2, 2, 5, RGB(FC[i % 4]));
        rect(sx, sy, 2, 2, RGB(0xf0d05a));
    }
    Item items[160]; int n = 0;
    for (int i = 0; i < ntrees && n < 150; i++) {
        float sx = SX(trees[i].x), sy = SY(trees[i].y);
        if (sx > -50 && sx < 450 && sy > -10 && sy < 300) items[n++] = (Item){trees[i].y, 0, i};
    }
    items[n++] = (Item){player.y, 1, 0};
    items[n++] = (Item){vis[0].y, 1, 1};
    items[n++] = (Item){vis[1].y, 1, 2};
    qsort(items, n, sizeof(Item), cmpItem);
    for (int i = 0; i < n; i++) {
        if (items[i].type == 0) {
            Tree *tr = &trees[items[i].idx];
            drawTree(tr, SX(tr->x), SY(tr->y));
        } else {
            Char *c = items[i].idx == 0 ? &player : &vis[items[i].idx - 1];
            drawChar(c, roundf(SX(c->x)), roundf(SY(c->y)));
        }
    }
    for (int i = 0; i < 32; i++)
        if (bursts[i].life > 0) {
            float k = 1.1f - bursts[i].life;
            u8 a = (u8)(CLAMP(bursts[i].life, 0.0f, 1.0f) * 255);
            rect(SX(bursts[i].x) - 3, SY(bursts[i].y) - k * 42, 6, 6, C2D_Color32(255, 248, 221, a));
        }
    (void)t;
    if (bannerAlpha > 0) {
        float w = txtW(ZNAME[zoneBanner], 0.7f) + 28;
        rect(200 - w / 2, 8, w, 28, C2D_Color32(251, 245, 232, (u8)(bannerAlpha * 240)));
        txt(ZNAME[zoneBanner], 200, 10, 0.7f, C2D_Color32(0x34, 0x45, 0x3e, (u8)(bannerAlpha * 255)), 1);
    }
    u64 now = osGetTime();
    int shown = 0;
    for (int i = nchat - 1; i >= 0 && shown < 4; i--) {
        if (now - chat[i].at > 10000) continue;
        char b[100]; snprintf(b, sizeof b, "%s: %.50s", chat[i].name, chat[i].text);
        float w = txtW(b, 0.42f) + 10;
        rect(6, 240 - 22 - shown * 17, w, 16, RGBA(0xfbf5e8, 235));
        txt(b, 11, 240 - 22 - shown * 17, 0.42f, RGB(0x34453e), 0);
        shown++;
    }
    txt("A play  Y chat  X name  SELECT sound", 394, 226, 0.36f, RGB(0x34453e), 0);
}

/* bottom screen: motif editor */
#define EX 16
#define EY 22
#define CW 18
#define CH 13
static void drawEditor(int playCol, const char *status) {
    txt("Custom Motif", 6, 2, 0.5f, RGB(0x34453e), 0);
    char who[40]; snprintf(who, sizeof who, "You: %s", username);
    txt(who, 314, 6, 0.38f, RGB(0x527661), 0);
    for (int s = 0; s < 16; s++) {
        u32 bg = (s / 4) % 2 == 0 ? RGB(0xf0e9d3) : RGB(0xf7f1df);
        if (s == playCol) bg = RGB(0xe9d9a5);
        rect(EX + s * CW, EY, CW - 1, CH * 15, bg);
    }
    for (int p = 0; p < 15; p++) {
        int row = 14 - p;
        rect(EX, EY + row * CH, CW * 16, 1, RGB(0xc7baa2));
        if (p % 7 == 0 || p == 4) txt(PITCH[p], 0, EY + row * CH - 1, 0.3f, RGB(0x607461), 0);
    }
    for (int s = 0; s < 16; s++)
        if (saved[s] >= 0) {
            float cx = EX + s * CW + CW / 2.0f - 0.5f, cy = EY + (14 - saved[s]) * CH + CH / 2.0f;
            C2D_DrawCircleSolid(cx, cy, Z, 5.5f, RGB(0x527661));
        }
    rect(16, 220, 84, 18, RGB(0x527661));   txt("Play", 58, 221, 0.5f, RGB(0xffffff), 1);
    rect(110, 220, 84, 18, RGB(0xede8d7));  txt("Clear", 152, 221, 0.5f, RGB(0x34453e), 1);
    txt(status, 204, 223, 0.38f, RGB(0x52695a), 0);
}

/* ----------------------------------------------------------------- main */
int main(void) {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    tbuf = C2D_TextBufNew(4096);

    audioInit();
    loadSave();
    buildWorld();
    initChar(&player, 2100, 1830, 0xf3cfae, 0x4f4244, 0xd9a07a, 0xc68b66, 0x6e7f8f, 0x5a4540, 0xf2b8b0, username, 0, 0);
    initChar(&vis[0], 1850, 1700, 0xefc9a8, 0x6b4a44, 0xd98e88, 0xc47a75, 0x7a6a86, 0x4e3d45, 0xf7e2a0, "Mira (demo)", 1.0f, 7);
    initChar(&vis[1], 2500, 1960, 0xc0896a, 0x3f3a3d, 0x8da9bd, 0x7895ab, 0x8a7a5e, 0x463a34, 0xe8b84f, "Pip (demo)", 2.5f, 15);
    sing[0].who = &player; sing[1].who = &vis[0]; sing[2].who = &vis[1];
    static const int8_t TUNE[2][8] = {{2,4,5,7,5,4,2,-1},{7,6,4,5,4,2,1,-1}};

    camx = CLAMP(player.x - 400, 0.0f, (float)(WW - 800));
    camy = CLAMP(player.y - 264, 0.0f, (float)(WH - 480));
    int zone = zoneAt(player.x, player.y), bannerZone = zone;
    float bannerT = 2.8f;
    char status[48] = "Tap the grid to edit";
    u64 last = osGetTime();
    float elapsed = 0;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kd = hidKeysDown(), kh = hidKeysHeld();
        if (kd & KEY_START) break;
        u64 now = osGetTime();
        float dt = CLAMP((now - last) / 1000.0f, 0.0f, 0.05f);
        last = now; elapsed += dt;

        /* movement */
        circlePosition cp; hidCircleRead(&cp);
        float dx = cp.dx / 156.0f, dy = -cp.dy / 156.0f;
        if (fabsf(dx) < 0.15f) dx = 0;
        if (fabsf(dy) < 0.15f) dy = 0;
        dx += !!(kh & KEY_DRIGHT) - !!(kh & KEY_DLEFT);
        dy += !!(kh & KEY_DDOWN) - !!(kh & KEY_DUP);
        float len = hypotf(dx, dy);
        if (len > 0.01f) stepTo(&player, dx, dy, len, dt, 230.0f * fminf(len, 1.0f));
        else player.moving = false;

        /* visitors */
        for (int i = 0; i < 2; i++) {
            Char *v = &vis[i];
            if (v->wait > 0) { v->wait -= dt; v->moving = false; }
            else {
                float ddx = v->tx - v->x, ddy = v->ty - v->y, d = hypotf(ddx, ddy);
                if (d < 8) { v->wait = 1.5f + rnd() * 3.5f; pickTarget(v); v->moving = false; }
                else if (!stepTo(v, ddx, ddy, d, dt, 48.0f)) { v->wait = .5f; pickTarget(v); }
            }
            v->sing -= dt;
            if (v->sing <= 0) { v->sing = 18 + rnd() * 25; singerStart(i + 1, TUNE[i], 8); }
        }

        /* buttons */
        if (kd & KEY_SELECT) { muted = !muted; snprintf(status, sizeof status, muted ? "Sound: off" : "Sound: on"); }
        if (kd & KEY_A) {
            bool any = false;
            for (int i = 0; i < 16; i++) if (saved[i] >= 0) any = true;
            if (any) singerStart(0, saved, 16); else snprintf(status, sizeof status, "Add a note first");
        }
        if (kd & KEY_Y) {
            char b[121] = {0};
            if (askText("Say something...", b, sizeof b, 1, 120)) {
                addChat(username, b);
                snprintf(player.say, sizeof player.say, "%s", b);
                player.sayUntil = osGetTime() + 6000;
            }
            last = osGetTime();
        }
        if (kd & KEY_X) {
            char b[40] = {0};
            if (askText("2-16 letters, numbers, spaces, _ -", b, sizeof b, 2, 16)) {
                if (validName(b)) {
                    snprintf(username, sizeof username, "%s", b);
                    snprintf(player.name, sizeof player.name, "%s", b);
                    saveNow();
                } else snprintf(status, sizeof status, "Invalid name");
            }
            last = osGetTime();
        }

        /* touch editor */
        if (kd & KEY_TOUCH) {
            touchPosition tp; hidTouchRead(&tp);
            int s = (tp.px - EX) / CW, row = (tp.py - EY) / CH;
            if (tp.px >= EX && s < 16 && tp.py >= EY && row < 15) {
                int p = 14 - row;
                saved[s] = saved[s] == p ? -1 : p;
                if (saved[s] >= 0) playNote(p, 0.6f, 0);
                saveNow();
            } else if (tp.py >= 220 && tp.px >= 16 && tp.px < 100) {
                bool any = false;
                for (int i = 0; i < 16; i++) if (saved[i] >= 0) any = true;
                if (any) singerStart(0, saved, 16); else snprintf(status, sizeof status, "Add a note first");
            } else if (tp.py >= 220 && tp.px >= 110 && tp.px < 194) {
                memset(saved, -1, sizeof saved); saveNow();
                snprintf(status, sizeof status, "Cleared");
            }
        }

        singersUpdate(osGetTime());
        for (int i = 0; i < 32; i++) if (bursts[i].life > 0) bursts[i].life -= dt;

        /* camera + zone banner */
        float tx = CLAMP(player.x - 400, 0.0f, (float)(WW - 800));
        float ty = CLAMP(player.y - 264, 0.0f, (float)(WH - 480));
        float k = 1 - expf(-dt * 7);
        camx += (tx - camx) * k; camy += (ty - camy) * k;
        int z = zoneAt(player.x, player.y);
        if (z != zone) { zone = z; bannerZone = z; bannerT = 2.8f; }
        if (bannerT > 0) bannerT -= dt;

        /* render */
        C2D_TextBufClear(tbuf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top, RGB(0xd6dfc2)); C2D_SceneBegin(top);
        drawWorld(elapsed, bannerZone, CLAMP(bannerT, 0.0f, 0.4f) / 0.4f);
        C2D_TargetClear(bot, RGB(0xfbf5e8)); C2D_SceneBegin(bot);
        drawEditor(sing[0].on ? sing[0].step - 1 : -1, status);
        C3D_FrameEnd(0);
    }

    if (audioOk) {
        ndspExit();
        for (int i = 0; i < 15; i++) if (notebuf[i]) linearFree(notebuf[i]);
    }
    C2D_TextBufDelete(tbuf);
    C2D_Fini(); C3D_Fini(); gfxExit();
    return 0;
}
